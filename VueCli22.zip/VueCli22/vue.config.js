const UglifyJsPlugin = require("uglifyjs-webpack-plugin");
const path = require("path");
function resolve (dir) {
  return path.join(__dirname, dir);
}
// ---
function addStyleResource (rule) {
  rule.use('style-resource')
    .loader('style-resources-loader')
    .options({
      patterns: [
        path.resolve(__dirname, 'src/less/index.less'),//全局引入的less文件
      ],
    })
}
// ---
module.exports = {
  publicPath: "",
  outputDir: "dist",
  assetsDir: "static",
  indexPath: "index.html",
  lintOnSave: false,
  runtimeCompiler: false,
  productionSourceMap: process.env.NODE_ENV === 'production' ? false : true,
  css: {
    extract: true,
    sourceMap: false,
  },
  chainWebpack: config => {
    config.resolve.alias
      .set("@", resolve("src"))
      .set("components", resolve("src/components"))
      .set("static", resolve("/static"));
    config.module
      .rule("images")
      .use("image-webpack-loader")
      .loader("image-webpack-loader")
      .options({
        disable: true,
        gifsicle: { interlaced: false },
        mozjpeg: { progressive: true, quality: 75 },
        optipng: { enabled: false },
        pngquant: { quality: "75-90", speed: 4 },
        webp: { quality: 75 }
      });
    // ---
    const types = ['vue-modules', 'vue', 'normal-modules', 'normal']
    types.forEach(type => addStyleResource(config.module.rule('less').oneOf(type)))
    // ---
  },
  configureWebpack: config => {
    config.plugins.push(
      // 上线压缩去除console等信息
      new UglifyJsPlugin({
        uglifyOptions: {
          warnings: false,
          compress: {
            drop_console: true,
            drop_debugger: false,
            pure_funcs: ["console.log"] // 移除console
          }
        },
        sourceMap: false,
        parallel: true
      })
    );
  },
  devServer: {
    hot: true,
    open: true,
    proxy: {
      "/Api": {
        // eslint-disable-next-line quotes
        target: "https://account.9buqi.com/api",
        changeOrigin: true,
        pathRewrite: {
          "^/Api": ""
        }
      }
    },
    overlay: {
      warnings: false,
      errors: false
    }
  }
};
