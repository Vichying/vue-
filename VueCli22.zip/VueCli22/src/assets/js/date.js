// 时间戳转时间
export function formatDate(time, fmt) {
  if(time == null ||time == '' || time ==undefined ){
    return ;
  }
  let date = new Date(time);
  
  // 格式默认  年-月-日
  if(fmt == null ||fmt == '' || fmt ==undefined){
    fmt = 'yyyy-MM-dd hh:mm:ss'
  }
  
  if (/(y+)/.test(fmt)) {
    fmt = fmt.replace(RegExp.$1, (date.getFullYear() + '').substr(4 - RegExp.$1.length));
  }
  let o = {
    'M+': date.getMonth() + 1,
    'd+': date.getDate(),
    'h+': date.getHours(),
    'm+': date.getMinutes(),
    's+': date.getSeconds()
  };
  for (let k in o) {
    if (new RegExp(`(${k})`).test(fmt)) {
      let str = o[k] + '';
      fmt = fmt.replace(RegExp.$1, (RegExp.$1.length === 1) ? str : padLeftZero(str));
    }
  }
  return fmt;
};
 
function padLeftZero(str) {
  return ('00' + str).substr(str.length);
}

// 时间字符串转时间戳
export function stampDate(string) {
  if(string == null ||string == '' || string ==undefined ){
    return ;
  }
  let date = new Date(string).getTime();
  
  if(!(typeof date === 'number' && isNaN(date)) && date != undefined){
    return date
  }else{
    return ''
  }
};





// let date=new Date(item.lastLoginTime)
// date.getFullYear(); 
// date.mouth=date.getMonth()+1;
// date.getDate(); 
// date.getHours(); 
// date.getMinutes(); 
// date.getSeconds(); // 获取秒数(0-59)
// item.lastLoginTime=date.getFullYear()+"-"+date.mouth+"-"+date.getDate()+" / "+date.getHours()+":"+date.getMinutes()+":"+date.getSeconds()