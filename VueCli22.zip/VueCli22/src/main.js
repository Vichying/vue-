import Vue from "vue";
import router from "./router";
import store from "./store";
import Vant from 'vant';
import 'vant/lib/index.css';
import "../static/css/base.css";
import axios from "./http/axios";
import Qs from "qs";
import App from "./App";
import { Lazyload } from 'vant';
import './assets/font/iconfont.css'

Vue.use(Lazyload);

Vue.use(Vant);

Vue.prototype.Qs = Qs

Vue.config.productionTip = false;

// router.beforeEach((to, from, next) => {
//   let token = sessionStorage.getItem("token");
//   console.log(token)
//   if (!token) {
//     if (to.path !== "/") {
//       return next("/");
//     }
//   }
//   next();
// });


/* eslint-disable no-new */
let vue = new Vue({
  router,
  store,
  components: {
    App
  },
  render: h => h(App)
}).$mount("#app");