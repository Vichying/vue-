import instance from "./axios.js";
/*api 命名
  query search相关的接口
  get  dataList相关的接口
  up  更新 编辑
  add 添加
  del 删除
  load 上传
*/
/* const destroyLogin = (params) => instance.post(baseC + "/apiuser/login/destroy", params) //注销
const getShopInfo = (params) => instance.get(baseC + "/apishop/shop/shopinfo", { params})  */

export {

};