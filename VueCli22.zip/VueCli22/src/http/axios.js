import axios from "axios";
import baseURL from "./env"
import { Message } from "element-ui";
let instance = axios.create();
/*-----------------instance基本配置-----------*/
instance.defaults.baseURL = baseURL
instance.defaults.headers.post["Content-Type"] =
  "application/x-www-form-urlencoded";

// 添加请求拦截器
instance.interceptors.request.use(
  function (config) {
    let token = sessionStorage.getItem("token");
    if (token) {
      config.headers["Authorization"] = JSON.parse(token);
    }
    return config;
  },
  function (error) {
    // 对请求错误做些什么
    return Promise.reject(error);
  }
);

// 响应
instance.interceptors.response.use(
  function (response) {
    const data = response.data;
    return data;
  },
  function (err) {
    // 对响应错误做点什么
    if (err && err.response) {
      console.log("TCL:  err.response", err.response);
      switch (err.response.status || err.response.resp_code) {
        case 400:
          Message.error(err.response.data.resp_msg);
          break;
        case 401:
          Message.error(err.response.data.resp_msg);
          break;
        case 403:
          Message.error("code:" + err.response.status + ",拒绝访问");
          return;
        case 404:
          Message.error(err.response.data.resp_msg || "调用api异常");
          break;
        case 408:
          Message.error("code:" + err.response.status + ",请求超时");
          break;
        case 500:
          Message.error(
            "code:" + err.response.status + "," + err.response.data.resp_msg
          );
          break;
        case 501:
          Message.error("code:" + err.response.status + ",服务未实现");
          break;
        case 502:
          Message.error("code:" + err.response.status + ",网关错误");
          break;
        case 503:
          Message.error("code:" + err.response.status + ",服务不可用");
          break;
        case 504:
          Message.error("code:" + err.response.status + ",网关超时");
          break;
        case 505:
          Message.error("code:" + err.response.status + ",HTTP版本不受支持");
          break;
        default:
      }
    }
    return Promise.reject(err);
  }
);
export default instance;

/*-----------------instance基本配置-----------*/
