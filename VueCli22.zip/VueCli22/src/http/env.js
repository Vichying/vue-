let baseURL;
if (process.env.NODE_ENV === 'development') {
  baseURL = ''; //测试环境      
} else {
  baseURL = "" 
}

export default baseURL