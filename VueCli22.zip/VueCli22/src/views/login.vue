<template>
  <div class="appContainer">
    
  </div>
</template>

<script>
import { Toast } from 'vant';
export default {
  data () {
    return {
      
    }
  },
  created () { },
  mounted () { },
  components: {},
  methods: {
  }
}
</script>

<style lang="less" scoped>
</style>
<style lang="less" scoped>
// @import "@/assets/css/loginAndRegister.less";
</style>
