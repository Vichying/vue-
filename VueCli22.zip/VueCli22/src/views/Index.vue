<template>
  <div class="appContainer">
  </div>
</template>

<script>
import { Toast } from 'vant';
export default {
  name: "index",
  data () {
    return {

    };
  },
  components: {

  },
  created () {

  },
  computed: {

  },
  mounted () { },
  methods: {

  }
};
</script>

<style lang="less" scoped>
</style>
