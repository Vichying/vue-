<template>
  <div class="appContainer">

  </div>
</template>

<script>
export default {
  data () {
      return {}
  },
  created () {},
  mounted () {},
  components: {},
  methods: {},
}
</script>

<style lang="less" scoped>
  
</style>
