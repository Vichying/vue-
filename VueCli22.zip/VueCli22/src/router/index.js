import Vue from 'vue'
import VueRouter from 'vue-router'
import Index from '@/views/Index'

Vue.use(VueRouter)

const routes = [
  {
    path: '/Index',
    name: 'Index',
    component: Index,
    children: [],
  },
  {
    path: '/',
    component: () => import('@/views/login'),
    name: 'login',
  },
  {
    path: '*',
    redirect: '/index',
  },
  // 测试
  {
    path: '/test',
    component: () => import('@/views/pages/test'),
    name: 'test',
    meta: { requireAuth: true }
  },
]

const router = new VueRouter({
  routes,
})

export default router
